import { pgTable, text, serial, integer, real, boolean, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const moviesTable = pgTable("movies", {
  id: serial("id").primaryKey(),
  titleEn: text("title_en").notNull(),
  titleKu: text("title_ku").notNull(),
  year: integer("year").notNull(),
  genre: text("genre").notNull(),
  type: text("type").notNull().default("movie"),
  imageUrl: text("image_url"),
  description: text("description"),
  isKurdish: boolean("is_kurdish").notNull().default(false),
  subtitleStatus: text("subtitle_status"),
  kurdishSummaryAi: text("kurdish_summary_ai"),
  availablePlatforms: text("available_platforms"),
  director: text("director"),
  cast: text("cast"),
  runtime: integer("runtime"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("movies_title_en_idx").on(table.titleEn),
  index("movies_title_ku_idx").on(table.titleKu),
  index("movies_genre_idx").on(table.genre),
]);

export const insertMovieSchema = createInsertSchema(moviesTable).omit({ id: true, createdAt: true });
export type InsertMovie = z.infer<typeof insertMovieSchema>;
export type Movie = typeof moviesTable.$inferSelect;

export const watchlistTable = pgTable("watchlist", {
  id: serial("id").primaryKey(),
  movieId: integer("movie_id").notNull().references(() => moviesTable.id, { onDelete: "cascade" }),
  rating: real("rating"),
  review: text("review"),
  watchedAt: timestamp("watched_at").notNull().defaultNow(),
});

export const insertWatchEntrySchema = createInsertSchema(watchlistTable).omit({ id: true, watchedAt: true });
export type InsertWatchEntry = z.infer<typeof insertWatchEntrySchema>;
export type WatchEntry = typeof watchlistTable.$inferSelect;

export const favoritesTable = pgTable("favorites", {
  id: serial("id").primaryKey(),
  movieId: integer("movie_id").notNull().references(() => moviesTable.id, { onDelete: "cascade" }),
  position: integer("position").notNull(),
});

export const insertFavoriteSchema = createInsertSchema(favoritesTable).omit({ id: true });
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;
export type Favorite = typeof favoritesTable.$inferSelect;
