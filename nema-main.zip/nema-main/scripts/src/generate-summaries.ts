import OpenAI from "openai";
import { db, moviesTable } from "@workspace/db";
import { isNull, or, eq } from "drizzle-orm";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY ?? "dummy",
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

async function generateKurdishSummary(titleEn: string, description: string, genre: string, year: number, type: string): Promise<string> {
  const typeKu = type === "series" ? "زنجیرە" : "فیلم";
  const prompt = `You are a Kurdish (Sorani) cinema expert. Write a brief, engaging movie/series summary in NATURAL CONVERSATIONAL SORANI KURDISH (not Kurmanji).

Rules:
- Exactly 2 sentences only
- Warm, engaging tone like recommending to a Kurdish friend
- Use Sorani Kurdish script only (کوردی سۆرانی)
- Do NOT translate the title — keep the English title as-is (e.g. "Inception" stays "Inception")
- First sentence should introduce what the story is about
- Second sentence should hint at why it's worth watching

Movie/Series: "${titleEn}" (${year}) — ${typeKu} — Genre: ${genre}
English description: ${description}

Write ONLY the 2 Sorani Kurdish sentences, nothing else:`;

  const response = await openai.chat.completions.create({
    model: "gpt-5-mini",
    max_completion_tokens: 250,
    messages: [{ role: "user", content: prompt }],
  });

  return response.choices[0]?.message?.content?.trim() ?? "";
}

async function sleep(ms: number) {
  return new Promise(r => setTimeout(r, ms));
}

async function main() {
  console.log("🎬 Generating Kurdish AI summaries for all movies...\n");

  const movies = await db
    .select()
    .from(moviesTable)
    .where(or(isNull(moviesTable.kurdishSummaryAi), eq(moviesTable.kurdishSummaryAi, "")));

  console.log(`Found ${movies.length} movies needing Kurdish summaries\n`);

  let success = 0;
  let failed = 0;

  for (let i = 0; i < movies.length; i++) {
    const movie = movies[i];
    const desc = movie.description || `A ${movie.genre} ${movie.type} from ${movie.year}.`;

    process.stdout.write(`[${i + 1}/${movies.length}] ${movie.titleEn}... `);

    try {
      const summary = await generateKurdishSummary(
        movie.titleEn, desc, movie.genre, movie.year, movie.type
      );

      if (summary) {
        await db
          .update(moviesTable)
          .set({ kurdishSummaryAi: summary })
          .where(eq(moviesTable.id, movie.id));
        process.stdout.write(`✅\n`);
        success++;
      } else {
        process.stdout.write(`⚠️ empty response\n`);
        failed++;
      }
    } catch (err: any) {
      process.stdout.write(`❌ ${err.message?.slice(0, 80)}\n`);
      failed++;
    }

    // Rate limit: 500ms between calls
    await sleep(500);
  }

  console.log(`\n✅ Done! ${success} summaries generated, ${failed} failed`);
  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
