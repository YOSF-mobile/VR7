import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BottomNav } from "@/components/BottomNav";
import Home from "@/pages/Home";
import Discover from "@/pages/Discover";
import Profile from "@/pages/Profile";
import Log from "@/pages/Log";
import TopRated from "@/pages/TopRated";
import AddMovie from "@/pages/AddMovie";
import MovieDetail from "@/pages/MovieDetail";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: 1,
    },
  },
});

function Router() {
  return (
    <>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/discover" component={Discover} />
        <Route path="/top-rated" component={TopRated} />
        <Route path="/profile" component={Profile} />
        <Route path="/log" component={Log} />
        <Route path="/add" component={AddMovie} />
        <Route path="/movie/:id" component={MovieDetail} />
        <Route component={NotFound} />
      </Switch>
      <BottomNav />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <Router />
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
