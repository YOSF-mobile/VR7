import { useListFavorites, useDeleteFavorite, useGetMovieStats, useListWatchlist, getListFavoritesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { StarRating } from "@/components/StarRating";
import { CircleUser, X, Plus } from "lucide-react";

const GENRE_KU: Record<string, string> = {
  "Drama": "دراما", "Action": "ئەکشن", "Sci-Fi": "ساینس فیکشن",
  "Crime": "تاوانکاری", "Thriller": "تریلەر", "Fantasy": "فانتازی",
  "Animation": "ئەنیمەیشن", "Romance": "ئاشقانە", "Documentary": "بەلگەنامە",
  "Western": "ڕۆژئاوا",
};

export default function Profile() {
  const { data: favorites = [] } = useListFavorites();
  const { data: stats } = useGetMovieStats();
  const { data: watchlist = [] } = useListWatchlist();
  const { mutate: deleteFavorite } = useDeleteFavorite();
  const queryClient = useQueryClient();

  const slots = [1, 2, 3, 4];

  const handleRemoveFavorite = (id: number) => {
    deleteFavorite({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFavoritesQueryKey() });
      }
    });
  };

  return (
    <div className="min-h-screen pb-24" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-b from-zinc-900 to-transparent px-4 pt-8 pb-6">
        <div className="max-w-md mx-auto text-center">
          <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-500/40 mx-auto flex items-center justify-center mb-3">
            <CircleUser size={32} className="text-amber-400" strokeWidth={1.5} />
          </div>
          <h1 className="text-lg font-bold text-white">پرۆفایلی من</h1>
          <p className="text-zinc-500 text-xs mt-1">کینەماتیکەڕۆژنامەی تۆ</p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 space-y-6">
        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-4">
              <p className="text-3xl font-black text-amber-400">{stats.totalWatched}</p>
              <p className="text-xs text-zinc-500 mt-1">کۆی فیلم بینیوەکان</p>
            </div>
            <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-4">
              <p className="text-3xl font-black text-amber-400">{stats.avgRating > 0 ? stats.avgRating : "—"}</p>
              <p className="text-xs text-zinc-500 mt-1">ناوەڕاستی نمرە</p>
            </div>
            <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-4">
              <p className="text-3xl font-black text-amber-400">{stats.totalMovies}</p>
              <p className="text-xs text-zinc-500 mt-1">کۆی فیلمەکان</p>
            </div>
            <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-4">
              <p className="text-3xl font-black text-amber-400">{stats.totalKurdish}</p>
              <p className="text-xs text-zinc-500 mt-1">فیلمی کوردی</p>
            </div>
          </div>
        )}

        {/* Genre Breakdown */}
        {stats && stats.genreBreakdown.length > 0 && (
          <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-4">
            <h2 className="text-sm font-bold text-white mb-3">جۆری فیلم</h2>
            <div className="space-y-2">
              {stats.genreBreakdown.slice(0, 5).map((item) => {
                const max = stats.genreBreakdown[0]?.count || 1;
                const pct = Math.round((item.count / max) * 100);
                return (
                  <div key={item.genre} className="flex items-center gap-3">
                    <span className="text-xs text-zinc-400 w-24 text-right flex-shrink-0">
                      {GENRE_KU[item.genre] || item.genre}
                    </span>
                    <div className="flex-1 bg-zinc-800 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full transition-all duration-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="text-xs text-zinc-500 w-4">{item.count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Top 4 Favorites */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-white">چوار دڵخوازەکەم</h2>
            <Link href="/discover">
              <span className="text-xs text-amber-500 cursor-pointer flex items-center gap-1">
                <Plus size={12} />
                زیادکردن
              </span>
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {slots.map((pos) => {
              const fav = favorites.find(f => f.position === pos);
              return (
                <div key={pos} className="relative aspect-[2/3] rounded-2xl overflow-hidden">
                  {fav?.movie ? (
                    <>
                      <Link href={`/movie/${fav.movie.id}`}>
                        <img
                          src={fav.movie.imageUrl || "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsLMd87K18qm6.jpg"}
                          alt={fav.movie.titleKu}
                          className="w-full h-full object-cover cursor-pointer"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop";
                          }}
                        />
                      </Link>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                      <div className="absolute bottom-0 right-0 left-0 p-2">
                        <p className="text-white text-xs font-semibold line-clamp-2">{fav.movie.titleKu}</p>
                      </div>
                      <button
                        onClick={() => handleRemoveFavorite(fav.id)}
                        className="absolute top-2 left-2 w-6 h-6 rounded-full bg-black/60 text-red-400 flex items-center justify-center hover:bg-red-500/30 transition-colors"
                      >
                        <X size={12} />
                      </button>
                      <div className="absolute top-2 right-2 bg-amber-500/80 text-black text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center">
                        {pos}
                      </div>
                    </>
                  ) : (
                    <Link href="/discover">
                      <div className="w-full h-full bg-zinc-900/80 border-2 border-dashed border-zinc-800 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-amber-500/30 hover:bg-zinc-900 transition-all">
                        <Plus size={20} className="text-amber-500/40" />
                        <span className="text-zinc-600 text-[10px] mt-1">دڵخواز {pos}</span>
                      </div>
                    </Link>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Reviews */}
        {watchlist.filter(e => e.review).length > 0 && (
          <div>
            <h2 className="text-sm font-bold text-white mb-3">دوایین ڕەخنەکان</h2>
            <div className="space-y-3">
              {watchlist.filter(e => e.review).slice(0, 3).map((entry) => (
                <div key={entry.id} className="bg-zinc-900/80 border border-zinc-800/60 rounded-xl p-3">
                  <div className="flex items-start gap-2">
                    {entry.movie?.imageUrl && (
                      <img
                        src={entry.movie.imageUrl}
                        alt=""
                        className="w-10 h-14 object-cover rounded-lg flex-shrink-0"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=80&h=120&fit=crop";
                        }}
                      />
                    )}
                    <div className="flex-1">
                      <p className="text-white text-sm font-medium">{entry.movie?.titleKu}</p>
                      {entry.rating && <StarRating value={entry.rating} readonly size="sm" />}
                      <p className="text-zinc-400 text-xs mt-1 line-clamp-3">{entry.review}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
