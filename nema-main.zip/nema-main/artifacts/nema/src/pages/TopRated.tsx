import { useListWatchlist } from "@workspace/api-client-react";
import { StarRating } from "@/components/StarRating";
import { Link } from "wouter";
import { Trophy, Star } from "lucide-react";

const RATING_BANDS = [
  { stars: 5, label: "نایاب", color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/30" },
  { stars: 4, label: "زۆر باش", color: "text-amber-300", bg: "bg-amber-400/10 border-amber-400/20" },
  { stars: 3, label: "باش", color: "text-zinc-300", bg: "bg-zinc-700/20 border-zinc-700/40" },
  { stars: 2, label: "ناوەند", color: "text-zinc-400", bg: "bg-zinc-800/30 border-zinc-800/50" },
  { stars: 1, label: "خراپ", color: "text-zinc-500", bg: "bg-zinc-900/30 border-zinc-800/30" },
];

const FALLBACK = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=80&h=120&fit=crop";

export default function TopRated() {
  const { data: watchlist = [], isLoading } = useListWatchlist();

  const rated = watchlist.filter((e) => e.rating && e.rating > 0);
  const sorted = [...rated].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));

  const grouped = RATING_BANDS.map((band) => ({
    ...band,
    entries: sorted.filter((e) => Math.round(e.rating ?? 0) === band.stars),
  })).filter((g) => g.entries.length > 0);

  return (
    <div className="min-h-screen pb-24" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/95 backdrop-blur-xl border-b border-zinc-800/60">
        <div className="max-w-md mx-auto px-4 py-3">
          <div className="flex items-center gap-2">
            <Trophy size={18} className="text-amber-400" strokeWidth={2} />
            <h1 className="text-base font-bold text-white">ریزبەندی فیلمەکان</h1>
            <span className="mr-auto text-xs text-zinc-500">{rated.length} نمرەدراو</span>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 pt-4">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-zinc-900 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : rated.length === 0 ? (
          <div className="text-center py-20">
            <div className="flex justify-center mb-4">
              <Trophy size={48} className="text-zinc-700" strokeWidth={1} />
            </div>
            <p className="text-zinc-400 font-medium">هیچ فیلمێک نمرەت نەداوە</p>
            <p className="text-zinc-600 text-sm mt-2">فیلمێک ببینە و ستارە پێ بدە</p>
            <Link href="/discover">
              <button className="mt-5 px-5 py-2.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-xl text-sm hover:bg-amber-500/20 transition-colors">
                دۆزینەوەی فیلم
              </button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Summary strip */}
            <div className="grid grid-cols-5 gap-1.5">
              {RATING_BANDS.map((band) => {
                const count = sorted.filter(
                  (e) => Math.round(e.rating ?? 0) === band.stars
                ).length;
                return (
                  <div
                    key={band.stars}
                    className={`rounded-xl border p-2 text-center ${band.bg}`}
                  >
                    <p className={`text-lg font-black ${band.color}`}>{count}</p>
                    <div className="flex justify-center mt-0.5">
                      {Array.from({ length: band.stars }).map((_, i) => (
                        <Star
                          key={i}
                          size={8}
                          className="fill-amber-400 stroke-amber-400"
                        />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Rating bands */}
            {grouped.map((group) => (
              <div key={group.stars}>
                {/* Band header */}
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex gap-0.5">
                    {Array.from({ length: group.stars }).map((_, i) => (
                      <Star
                        key={i}
                        size={14}
                        className="fill-amber-400 stroke-amber-400"
                      />
                    ))}
                    {Array.from({ length: 5 - group.stars }).map((_, i) => (
                      <Star
                        key={i}
                        size={14}
                        className="fill-transparent stroke-zinc-700"
                      />
                    ))}
                  </div>
                  <span className={`text-sm font-bold ${group.color}`}>
                    {group.label}
                  </span>
                  <span className="text-zinc-600 text-xs mr-auto">
                    {group.entries.length} فیلم
                  </span>
                </div>

                {/* Entries */}
                <div className="space-y-2">
                  {group.entries.map((entry, idx) => (
                    <Link key={entry.id} href={`/movie/${entry.movie?.id}`}>
                      <div
                        className={`flex items-center gap-3 rounded-xl border p-2.5 cursor-pointer hover:brightness-110 transition-all ${group.bg}`}
                      >
                        {/* Rank badge */}
                        <div className="flex-shrink-0 w-7 h-7 rounded-full bg-black/40 flex items-center justify-center">
                          <span className={`text-xs font-black ${group.color}`}>
                            {idx + 1}
                          </span>
                        </div>

                        {/* Poster */}
                        <img
                          src={entry.movie?.imageUrl || FALLBACK}
                          alt={entry.movie?.titleKu ?? ""}
                          className="w-10 h-14 object-cover rounded-lg flex-shrink-0"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = FALLBACK;
                          }}
                        />

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <p className="text-white text-sm font-semibold line-clamp-1">
                            {entry.movie?.titleKu ?? "فیلمی نەناسراو"}
                          </p>
                          <p className="text-zinc-500 text-xs mt-0.5">
                            {entry.movie?.titleEn} · {entry.movie?.year}
                          </p>
                          <div className="mt-1">
                            <StarRating
                              value={entry.rating ?? 0}
                              readonly
                              size="sm"
                            />
                          </div>
                        </div>

                        {/* Rating badge */}
                        <div className={`flex-shrink-0 flex items-center gap-0.5 text-sm font-black ${group.color}`}>
                          <Star size={12} className="fill-amber-400 stroke-amber-400" />
                          <span>{entry.rating}</span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
