import { useState } from "react";
import { useCreateMovie, getListMoviesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";

const GENRES = ["Drama", "Action", "Sci-Fi", "Crime", "Thriller", "Fantasy", "Animation", "Romance", "Documentary", "Western", "Horror", "Comedy"];
const GENRE_KU: Record<string, string> = {
  "Drama": "دراما", "Action": "ئەکشن", "Sci-Fi": "ساینس فیکشن", "Crime": "تاوانکاری",
  "Thriller": "تریلەر", "Fantasy": "فانتازی", "Animation": "ئەنیمەیشن",
  "Romance": "ئاشقانە", "Documentary": "بەلگەنامە", "Western": "ڕۆژئاوا",
  "Horror": "ترسناک", "Comedy": "کۆمیدی",
};

export default function AddMovie() {
  const [, navigate] = useLocation();
  const { mutate: createMovie, isPending } = useCreateMovie();
  const queryClient = useQueryClient();

  const [form, setForm] = useState({
    titleKu: "",
    titleEn: "",
    year: new Date().getFullYear(),
    genre: "Drama",
    type: "movie" as "movie" | "series",
    imageUrl: "",
    description: "",
    isKurdish: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.titleKu.trim()) e.titleKu = "ناوی کوردی پێویستە";
    if (!form.titleEn.trim()) e.titleEn = "ناوی ئینگلیزی پێویستە";
    if (!form.year || form.year < 1900 || form.year > 2030) e.year = "ساڵی دروست بنووسە";
    return e;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    createMovie(
      {
        ...form,
        imageUrl: form.imageUrl || undefined,
        description: form.description || undefined,
      },
      {
        onSuccess: (movie) => {
          queryClient.invalidateQueries({ queryKey: getListMoviesQueryKey() });
          navigate(`/movie/${movie.id}`);
        },
      }
    );
  };

  const set = (field: string, value: unknown) => {
    setForm(p => ({ ...p, [field]: value }));
    setErrors(p => { const n = { ...p }; delete n[field]; return n; });
  };

  return (
    <div className="min-h-screen pb-24" dir="rtl">
      <div className="sticky top-0 z-40 bg-black/90 backdrop-blur-xl border-b border-zinc-800/60">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/")} className="text-zinc-500 hover:text-white transition-colors text-lg">‹</button>
          <h1 className="text-base font-bold text-white">زیادکردنی فیلم</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="max-w-md mx-auto px-4 pt-5 space-y-4">
        {/* Type toggle */}
        <div className="flex rounded-xl overflow-hidden border border-zinc-800">
          {[["movie", "فیلم"], ["series", "زنجیرە"]].map(([val, label]) => (
            <button
              key={val}
              type="button"
              onClick={() => set("type", val)}
              className={`flex-1 py-2.5 text-sm font-medium transition-colors ${
                form.type === val
                  ? "bg-amber-500 text-black"
                  : "bg-zinc-900 text-zinc-400 hover:text-zinc-200"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Kurdish title */}
        <div>
          <label className="block text-xs text-zinc-400 mb-1.5">ناوی کوردی *</label>
          <input
            type="text"
            value={form.titleKu}
            onChange={e => set("titleKu", e.target.value)}
            placeholder="نموونە: ئینتەرستیلەر، گۆدفادەر..."
            className="w-full bg-zinc-900/80 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-500/50 transition-colors"
            dir="rtl"
          />
          <p className="text-zinc-600 text-[10px] mt-1 text-right">ئەگەر ناوەکە ئینگلیزییە، ئەوا بنووسەیت بە ئینگلیزی بەڵام بە پیتی کوردی — نموونە: Interstellar ← ئینتەرستیلەر</p>
          {errors.titleKu && <p className="text-red-400 text-xs mt-1">{errors.titleKu}</p>}
        </div>

        {/* English title */}
        <div>
          <label className="block text-xs text-zinc-400 mb-1.5">ناوی ئینگلیزی *</label>
          <input
            type="text"
            value={form.titleEn}
            onChange={e => set("titleEn", e.target.value)}
            placeholder="English Title..."
            className="w-full bg-zinc-900/80 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-500/50 transition-colors"
            dir="ltr"
          />
          {errors.titleEn && <p className="text-red-400 text-xs mt-1">{errors.titleEn}</p>}
        </div>

        {/* Year & Genre */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-zinc-400 mb-1.5">ساڵ *</label>
            <input
              type="number"
              value={form.year}
              onChange={e => set("year", parseInt(e.target.value))}
              className="w-full bg-zinc-900/80 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500/50 transition-colors"
              dir="ltr"
              min={1900}
              max={2030}
            />
            {errors.year && <p className="text-red-400 text-xs mt-1">{errors.year}</p>}
          </div>
          <div>
            <label className="block text-xs text-zinc-400 mb-1.5">جۆر</label>
            <select
              value={form.genre}
              onChange={e => set("genre", e.target.value)}
              className="w-full bg-zinc-900/80 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500/50 transition-colors appearance-none"
            >
              {GENRES.map(g => (
                <option key={g} value={g}>{GENRE_KU[g] || g}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Image URL */}
        <div>
          <label className="block text-xs text-zinc-400 mb-1.5">لینکی وێنەی پۆستەر</label>
          <input
            type="url"
            value={form.imageUrl}
            onChange={e => set("imageUrl", e.target.value)}
            placeholder="https://..."
            className="w-full bg-zinc-900/80 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-500/50 transition-colors"
            dir="ltr"
          />
          {form.imageUrl && (
            <div className="mt-2 flex justify-center">
              <img
                src={form.imageUrl}
                alt="Preview"
                className="w-24 h-32 object-cover rounded-lg border border-zinc-800"
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
            </div>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-xs text-zinc-400 mb-1.5">پوختەی چیرۆک</label>
          <textarea
            value={form.description}
            onChange={e => set("description", e.target.value)}
            placeholder="کورتە چیرۆکی فیلم..."
            rows={3}
            className="w-full bg-zinc-900/80 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-500/50 transition-colors resize-none"
            dir="rtl"
          />
        </div>

        {/* Kurdish toggle */}
        <label className="flex items-center justify-between bg-zinc-900/80 border border-zinc-800/60 rounded-xl px-4 py-3 cursor-pointer">
          <div>
            <p className="text-sm text-white">فیلمی کوردیە؟</p>
            <p className="text-xs text-zinc-500">ئایا ئەمە بەرهەمێکی کوردیە؟</p>
          </div>
          <div
            className={`w-12 h-6 rounded-full transition-colors relative ${form.isKurdish ? "bg-amber-500" : "bg-zinc-800"}`}
            onClick={() => set("isKurdish", !form.isKurdish)}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${form.isKurdish ? "right-1" : "left-1"}`} />
          </div>
        </label>

        <button
          type="submit"
          disabled={isPending}
          className="w-full bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-bold py-3.5 rounded-xl transition-colors text-sm"
        >
          {isPending ? "زیادکردن..." : "زیادکردنی فیلم"}
        </button>
      </form>
    </div>
  );
}
