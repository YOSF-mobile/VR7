import { useGetRecentActivity, useGetMovieStats, useListMovies } from "@workspace/api-client-react";
import { MovieCard } from "@/components/MovieCard";
import { StarRating } from "@/components/StarRating";
import { formatDate } from "@/lib/utils";
import { Link } from "wouter";
import { Plus } from "lucide-react";

export default function Home() {
  const { data: recentActivity = [] } = useGetRecentActivity();
  const { data: stats } = useGetMovieStats();
  const { data: movies = [] } = useListMovies();

  const featuredMovie = movies[0];

  return (
    <div className="min-h-screen pb-24" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/80 backdrop-blur-xl border-b border-zinc-800/60">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-black text-amber-400 tracking-tight">نیما</h1>
          <Link href="/add">
            <button className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center hover:bg-amber-500/20 transition-colors">
              <Plus size={16} />
            </button>
          </Link>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 pt-4 space-y-6">
        {/* Stats Row */}
        {stats && (
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-3 text-center">
              <p className="text-2xl font-black text-amber-400">{stats.totalWatched}</p>
              <p className="text-[11px] text-zinc-500 mt-0.5">بینیوەکان</p>
            </div>
            <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-3 text-center">
              <p className="text-2xl font-black text-amber-400">
                {stats.avgRating > 0 ? stats.avgRating : "—"}
              </p>
              <p className="text-[11px] text-zinc-500 mt-0.5">ناوەڕاستی نمرە</p>
            </div>
            <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-3 text-center">
              <p className="text-2xl font-black text-amber-400">{stats.totalKurdish}</p>
              <p className="text-[11px] text-zinc-500 mt-0.5">فیلمی کوردی</p>
            </div>
          </div>
        )}

        {/* Featured Movie */}
        {featuredMovie && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-zinc-300">فیلمی تازە</h2>
              <Link href="/discover">
                <span className="text-xs text-amber-500 hover:text-amber-400 cursor-pointer">هەمووی ببینە</span>
              </Link>
            </div>
            <Link href={`/movie/${featuredMovie.id}`}>
              <div className="relative overflow-hidden rounded-2xl aspect-[16/9] bg-zinc-900 cursor-pointer group">
                <img
                  src={featuredMovie.imageUrl || "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsLMd87K18qm6.jpg"}
                  alt={featuredMovie.titleKu}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=800&h=450&fit=crop";
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent" />
                <div className="absolute bottom-0 right-0 left-0 p-4">
                  {featuredMovie.isKurdish && (
                    <span className="inline-block bg-amber-500/90 text-black text-[10px] font-bold px-2 py-0.5 rounded-full mb-2">
                      فیلمی کوردی
                    </span>
                  )}
                  <h3 className="text-white font-bold text-xl leading-tight">{featuredMovie.titleKu}</h3>
                  <p className="text-zinc-400 text-sm">{featuredMovie.titleEn} · {featuredMovie.year}</p>
                  {featuredMovie.description && (
                    <p className="text-zinc-500 text-xs mt-1 line-clamp-2">{featuredMovie.description}</p>
                  )}
                </div>
              </div>
            </Link>
          </div>
        )}

        {/* Recent Activity */}
        {recentActivity.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-zinc-300">دوایین بینیوەکان</h2>
              <Link href="/log">
                <span className="text-xs text-amber-500 hover:text-amber-400 cursor-pointer">هەمووی ببینە</span>
              </Link>
            </div>
            <div className="space-y-3">
              {recentActivity.slice(0, 5).map((entry) => (
                <div key={entry.id} className="flex items-start gap-3 bg-zinc-900/50 border border-zinc-800/60 rounded-xl p-3">
                  {entry.movie && (
                    <Link href={`/movie/${entry.movie.id}`}>
                      <img
                        src={entry.movie.imageUrl || "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsLMd87K18qm6.jpg"}
                        alt={entry.movie.titleKu}
                        className="w-12 h-16 object-cover rounded-lg flex-shrink-0 cursor-pointer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=80&h=120&fit=crop";
                        }}
                      />
                    </Link>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-semibold line-clamp-1">
                      {entry.movie?.titleKu || "فیلمی نەناسراو"}
                    </p>
                    <p className="text-zinc-500 text-xs">{entry.movie?.year}</p>
                    {entry.rating && (
                      <div className="mt-1">
                        <StarRating value={entry.rating} readonly size="sm" />
                      </div>
                    )}
                    {entry.review && (
                      <p className="text-zinc-400 text-xs mt-1 line-clamp-2">{entry.review}</p>
                    )}
                    <p className="text-zinc-600 text-[10px] mt-1">{formatDate(entry.watchedAt)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {recentActivity.length === 0 && (
          <div className="text-center py-12">
            <p className="text-5xl mb-3">🎬</p>
            <p className="text-zinc-400 text-sm">هیچ فیلمێک تۆمار نەکراوە</p>
            <p className="text-zinc-600 text-xs mt-1">فیلمێک ببینە و نمرەی بدەیت</p>
            <Link href="/discover">
              <button className="mt-4 px-4 py-2 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-xl text-sm hover:bg-amber-500/20 transition-colors">
                دۆزینەوەی فیلم
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
