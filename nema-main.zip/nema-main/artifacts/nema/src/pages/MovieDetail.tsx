import { useState } from "react";
import { useParams, useLocation } from "wouter";
import {
  useGetMovie,
  useCreateWatchEntry,
  useUpdateWatchEntry,
  useDeleteWatchEntry,
  useAddFavorite,
  useDeleteFavorite,
  useUpdateMovie,
  useListFavorites,
  getGetMovieQueryKey,
  getListFavoritesQueryKey,
  getListWatchlistQueryKey,
  getGetRecentActivityQueryKey,
  getGetMovieStatsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { StarRating } from "@/components/StarRating";
import { formatDate } from "@/lib/utils";
import {
  ChevronRight, Heart, CheckCircle, Clapperboard, Captions,
  ExternalLink, Globe, Clock, User, Users, Film, Star,
} from "lucide-react";

const SubtitleStatus = {
  available: "available",
  unavailable: "unavailable",
  in_progress: "in_progress",
} as const;
type SubtitleStatus = (typeof SubtitleStatus)[keyof typeof SubtitleStatus];

const GENRE_KU: Record<string, string> = {
  "Drama": "دراما", "Action": "ئەکشن", "Sci-Fi": "ساینس فیکشن",
  "Crime": "تاوانکاری", "Thriller": "تریلەر", "Fantasy": "فانتازی",
  "Animation": "ئەنیمەیشن", "Romance": "ئاشقانە", "Documentary": "بەلگەنامە",
  "Western": "ڕۆژئاوا", "Horror": "ترساوە", "Comedy": "کۆمیدی",
};

const SUBTITLE_META: Record<string, { ku: string; color: string; bg: string; border: string }> = {
  available:   { ku: "زیرنووسی کوردی هەیە",  color: "text-emerald-400", bg: "bg-emerald-500/15", border: "border-emerald-500/30" },
  in_progress: { ku: "زیرنووس لە کاردایە",    color: "text-amber-400",   bg: "bg-amber-500/15",   border: "border-amber-500/30"  },
  unavailable: { ku: "زیرنووسی کوردی نییە",   color: "text-red-400",     bg: "bg-red-500/15",     border: "border-red-500/30"    },
};

const WATCH_PLATFORMS = [
  { id: "Kurdcinema",   url: (t: string) => `https://kurdcinema.com/?s=${encodeURIComponent(t)}`,   color: "from-rose-800/30",    border: "border-rose-700/30",   label: "کوردسینەما",    site: "kurdcinema.com"   },
  { id: "Kurdfilm",     url: (t: string) => `https://kurdfilm.com/?s=${encodeURIComponent(t)}`,     color: "from-sky-800/30",     border: "border-sky-700/30",    label: "کوردفیلم",      site: "kurdfilm.com"     },
  { id: "Kurdsubtitle", url: (t: string) => `https://kurdsubtitle.com/?s=${encodeURIComponent(t)}`, color: "from-violet-800/30",  border: "border-violet-700/30", label: "کوردسەبتایتڵ",  site: "kurdsubtitle.com" },
  { id: "Shafilm",      url: (t: string) => `https://shafilm.com/?s=${encodeURIComponent(t)}`,      color: "from-emerald-800/30", border: "border-emerald-700/30",label: "شافیلم",         site: "shafilm.com"      },
  { id: "Beenar",       url: (t: string) => `https://beenar.net/?s=${encodeURIComponent(t)}`,       color: "from-amber-800/30",   border: "border-amber-700/30",  label: "بینار",          site: "beenar.net"       },
];

export default function MovieDetail() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const id = parseInt(params.id || "0");
  const queryClient = useQueryClient();

  const { data: movie, isLoading } = useGetMovie(id, {
    query: { queryKey: getGetMovieQueryKey(id) }
  });
  const { data: favorites = [] } = useListFavorites();

  const { mutate: createWatch, isPending: isCreating } = useCreateWatchEntry();
  const { mutate: updateWatch, isPending: isUpdating } = useUpdateWatchEntry();
  const { mutate: deleteWatch } = useDeleteWatchEntry();
  const { mutate: addFav, isPending: isAddingFav } = useAddFavorite();
  const { mutate: deleteFav, isPending: isDeletingFav } = useDeleteFavorite();
  const { mutate: updateMovie, isPending: isUpdatingMeta } = useUpdateMovie();

  const [rating, setRating] = useState(0);
  const [review, setReview] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [showFavPicker, setShowFavPicker] = useState(false);

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: getGetMovieQueryKey(id) });
    queryClient.invalidateQueries({ queryKey: getListWatchlistQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetRecentActivityQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetMovieStatsQueryKey() });
  };

  const handleWatch = () => {
    const entry = movie?.watchEntry;
    if (entry) {
      updateWatch(
        { id: entry.id, data: { movieId: id, rating: rating || undefined, review: review || undefined } },
        { onSuccess: () => { invalidateAll(); setShowForm(false); } }
      );
    } else {
      createWatch(
        { data: { movieId: id, rating: rating || undefined, review: review || undefined } },
        { onSuccess: () => { invalidateAll(); setShowForm(false); } }
      );
    }
  };

  const handleUnwatch = () => {
    if (!movie?.watchEntry) return;
    deleteWatch(
      { id: movie.watchEntry.id },
      { onSuccess: () => { invalidateAll(); } }
    );
  };

  const handleAddFav = (position: number) => {
    if (!movie) return;
    const existing = favorites.find(f => f.position === position);
    if (existing) {
      deleteFav({ id: existing.id }, {
        onSuccess: () => {
          addFav({ data: { movieId: id, position } }, {
            onSuccess: () => {
              queryClient.invalidateQueries({ queryKey: getListFavoritesQueryKey() });
              queryClient.invalidateQueries({ queryKey: getGetMovieQueryKey(id) });
              setShowFavPicker(false);
            }
          });
        }
      });
    } else {
      addFav({ data: { movieId: id, position } }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListFavoritesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetMovieQueryKey(id) });
          setShowFavPicker(false);
        }
      });
    }
  };

  const handleRemoveFav = () => {
    if (!movie) return;
    const favEntry = favorites.find(f => f.movieId === id);
    if (!favEntry) return;
    deleteFav({ id: favEntry.id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFavoritesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMovieQueryKey(id) });
      }
    });
  };

  const handleSubtitleStatus = (status: SubtitleStatus) => {
    if (!movie) return;
    const newStatus = movie.subtitleStatus === status ? undefined : status;
    updateMovie(
      {
        id,
        data: {
          titleEn: movie.titleEn,
          titleKu: movie.titleKu,
          year: movie.year,
          genre: movie.genre,
          type: movie.type as "movie" | "series",
          isKurdish: movie.isKurdish,
          imageUrl: movie.imageUrl ?? undefined,
          description: movie.description ?? undefined,
          subtitleStatus: newStatus,
        }
      },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetMovieQueryKey(id) }) }
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-zinc-500 text-sm">چاوەڕوان بە...</p>
        </div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="min-h-screen flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <Clapperboard size={48} className="text-zinc-600 mx-auto mb-3" strokeWidth={1} />
          <p className="text-zinc-400">فیلمەکە نەدۆزرایەوە</p>
          <button onClick={() => navigate("/")} className="mt-4 text-amber-400 text-sm">بگەڕێوە سەرەکی</button>
        </div>
      </div>
    );
  }

  const watched = !!movie.watchEntry;
  const favEntry = favorites.find(f => f.movieId === id);
  const isFavorite = !!favEntry;
  const subtitleMeta = movie.subtitleStatus ? SUBTITLE_META[movie.subtitleStatus] : null;
  const availablePlatforms: string[] = movie.availablePlatforms
    ? JSON.parse(movie.availablePlatforms)
    : [];
  const platformsToShow = availablePlatforms.length > 0
    ? WATCH_PLATFORMS.filter(p => availablePlatforms.includes(p.id))
    : WATCH_PLATFORMS;

  return (
    <div className="min-h-screen pb-24" dir="rtl">
      {/* Hero poster */}
      <div className="relative h-80 overflow-hidden">
        <img
          src={movie.imageUrl || ""}
          alt={movie.titleKu}
          className="w-full h-full object-cover object-top"
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=800&h=450&fit=crop";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/10 to-black" />
        <button
          onClick={() => navigate(-1 as never)}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/60 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/80 transition-colors"
        >
          <ChevronRight size={20} />
        </button>
        {isFavorite && (
          <div className="absolute top-4 left-4 bg-amber-500/90 text-black text-[10px] font-black px-2.5 py-1 rounded-full flex items-center gap-1">
            <Heart size={10} className="fill-current" />
            دڵخواز #{favEntry?.position}
          </div>
        )}
      </div>

      <div className="max-w-md mx-auto px-4 -mt-8 relative">
        {/* Title + meta */}
        <div className="mb-5">
          <div className="flex items-center gap-2 flex-wrap mb-2">
            {movie.isKurdish && (
              <span className="inline-block bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
                فیلمی کوردی
              </span>
            )}
            {subtitleMeta && (
              <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${subtitleMeta.bg} ${subtitleMeta.color} ${subtitleMeta.border}`}>
                <Captions size={9} />
                {subtitleMeta.ku}
              </span>
            )}
          </div>
          <h1 className="text-2xl font-black text-white leading-tight">{movie.titleKu}</h1>
          <p className="text-zinc-400 text-sm mt-0.5">{movie.titleEn}</p>

          <div className="flex items-center gap-2 mt-3 flex-wrap">
            <span className="bg-zinc-800/80 text-zinc-300 text-xs px-2.5 py-1 rounded-lg">{movie.year}</span>
            <span className="bg-zinc-800/80 text-zinc-300 text-xs px-2.5 py-1 rounded-lg">{GENRE_KU[movie.genre] || movie.genre}</span>
            <span className="bg-zinc-800/80 text-zinc-300 text-xs px-2.5 py-1 rounded-lg">
              {movie.type === "series" ? "زنجیرە" : "فیلم"}
            </span>
            {(movie as any).runtime && (
              <span className="bg-zinc-800/80 text-zinc-300 text-xs px-2.5 py-1 rounded-lg flex items-center gap-1">
                <Clock size={10} />
                {(movie as any).runtime} خولەک
              </span>
            )}
            {movie.watchEntry?.rating && (
              <span className="bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs px-2.5 py-1 rounded-lg flex items-center gap-1">
                <Star size={10} className="fill-amber-400" />
                {movie.watchEntry.rating}
              </span>
            )}
          </div>

          {/* Director & Cast */}
          {((movie as any).director || (movie as any).cast) && (
            <div className="mt-3 space-y-1.5">
              {(movie as any).director && (
                <div className="flex items-center gap-2 text-xs text-zinc-400">
                  <User size={11} className="text-zinc-600 shrink-0" />
                  <span className="text-zinc-600">دێرێکتەر:</span>
                  <span>{(movie as any).director}</span>
                </div>
              )}
              {(movie as any).cast && (
                <div className="flex items-start gap-2 text-xs text-zinc-400">
                  <Users size={11} className="text-zinc-600 shrink-0 mt-0.5" />
                  <span className="text-zinc-600 shrink-0">ئەکتەرەکان:</span>
                  <span className="leading-relaxed">{(movie as any).cast}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Kurdish AI Summary */}
        {(movie as any).kurdishSummaryAi && (
          <div className="bg-zinc-900/60 border border-zinc-800/60 rounded-2xl p-4 mb-5">
            <div className="flex items-center gap-2 mb-2">
              <Film size={12} className="text-amber-500" />
              <span className="text-[11px] text-amber-500 font-bold uppercase tracking-wide">پوختەی فیلم</span>
            </div>
            <p className="text-zinc-300 text-sm leading-loose text-right" dir="rtl">
              {(movie as any).kurdishSummaryAi}
            </p>
          </div>
        )}

        {/* English description fallback when no AI summary */}
        {!(movie as any).kurdishSummaryAi && movie.description && (
          <p className="text-zinc-400 text-sm leading-relaxed mb-5 border-r-2 border-amber-500/30 pr-3" dir="ltr" style={{ textAlign: "left" }}>
            {movie.description}
          </p>
        )}

        {/* Current watch entry */}
        {movie.watchEntry && (
          <div className="bg-zinc-900/80 border border-amber-500/20 rounded-2xl p-4 mb-5">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-amber-400 font-semibold flex items-center gap-1">
                <CheckCircle size={12} />
                تۆمارکراوە
              </p>
              <button onClick={handleUnwatch} className="text-zinc-600 hover:text-red-400 text-xs transition-colors">
                سڕینەوە
              </button>
            </div>
            {movie.watchEntry.rating && (
              <StarRating value={movie.watchEntry.rating} readonly size="md" showLabel />
            )}
            {movie.watchEntry.review && (
              <p className="text-zinc-300 text-sm mt-2 leading-relaxed">"{movie.watchEntry.review}"</p>
            )}
            <p className="text-zinc-600 text-xs mt-2">{formatDate(movie.watchEntry.watchedAt)}</p>
            <button
              onClick={() => { setRating(movie.watchEntry?.rating || 0); setReview(movie.watchEntry?.review || ""); setShowForm(true); }}
              className="mt-2 text-xs text-amber-500 hover:text-amber-400 transition-colors"
            >
              گۆڕانکاری
            </button>
          </div>
        )}

        {/* Action buttons */}
        <div className="flex gap-3 mb-5">
          <button
            onClick={() => setShowForm(!showForm)}
            className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
              watched
                ? "bg-amber-500/20 border border-amber-500/40 text-amber-400 hover:bg-amber-500/30"
                : "bg-amber-500 hover:bg-amber-400 text-black"
            }`}
          >
            {watched ? <><CheckCircle size={15} />بینیوەتە</> : <><Clapperboard size={15} />ببینە و نمرە بدە</>}
          </button>

          {/* Favorites button */}
          <button
            onClick={() => isFavorite ? handleRemoveFav() : setShowFavPicker(!showFavPicker)}
            disabled={isAddingFav || isDeletingFav}
            className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all relative ${
              isFavorite
                ? "bg-amber-500/30 border border-amber-500/50 text-amber-400"
                : "bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-amber-400 hover:border-amber-500/30"
            }`}
          >
            <Heart size={20} className={isFavorite ? "fill-amber-400" : ""} />
          </button>
        </div>

        {/* Fav position picker */}
        {showFavPicker && !isFavorite && (
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 mb-5">
            <p className="text-xs text-zinc-400 mb-3 text-center">کام شوێن دابنێ لە دڵخوازەکانت؟</p>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4].map(pos => {
                const taken = favorites.find(f => f.position === pos);
                return (
                  <button
                    key={pos}
                    onClick={() => handleAddFav(pos)}
                    disabled={isAddingFav}
                    className="flex flex-col items-center gap-1 p-2 rounded-xl border border-zinc-700 hover:border-amber-500/50 hover:bg-amber-500/10 transition-all"
                  >
                    <span className="text-amber-400 font-black text-lg">#{pos}</span>
                    {taken ? (
                      <img
                        src={taken.movie?.imageUrl ?? ""}
                        className="w-8 h-10 object-cover rounded opacity-50"
                        onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
                      />
                    ) : (
                      <div className="w-8 h-10 border border-dashed border-zinc-700 rounded" />
                    )}
                  </button>
                );
              })}
            </div>
            <button onClick={() => setShowFavPicker(false)} className="mt-3 w-full text-zinc-500 text-xs hover:text-zinc-400 transition-colors">
              داخستن
            </button>
          </div>
        )}

        {/* Rating form */}
        {showForm && (
          <div className="bg-zinc-900/80 border border-zinc-800/60 rounded-2xl p-4 mb-5 space-y-4">
            <h3 className="text-sm font-bold text-white">نمرە و ڕەخنەت بنووسە</h3>
            <div className="flex flex-col items-center gap-1">
              <StarRating value={rating} onChange={setRating} size="lg" showLabel />
            </div>
            <textarea
              value={review}
              onChange={e => setReview(e.target.value)}
              placeholder="بۆچیت لە ئەم فیلمە؟ بنووسە بە کوردی..."
              rows={4}
              className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-500/50 transition-colors resize-none"
              dir="rtl"
            />
            <div className="flex gap-3">
              <button
                onClick={handleWatch}
                disabled={isCreating || isUpdating}
                className="flex-1 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-bold py-2.5 rounded-xl text-sm transition-colors"
              >
                {isCreating || isUpdating ? "تۆمارکردن..." : "تۆمارکردن"}
              </button>
              <button onClick={() => setShowForm(false)} className="px-4 bg-zinc-800 text-zinc-400 rounded-xl text-sm hover:bg-zinc-700 transition-colors">
                داخستن
              </button>
            </div>
          </div>
        )}

        {/* Subtitle Status */}
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-3">
            <Captions size={14} className="text-zinc-500" />
            <h2 className="text-sm font-bold text-zinc-300">دۆخی زیرنووسی کوردی</h2>
          </div>
          <div className="flex gap-2">
            {([
              { status: SubtitleStatus.available,   label: "هەیە",       emoji: "✅", activeColor: "bg-emerald-500/25 border-emerald-500/50 text-emerald-300" },
              { status: SubtitleStatus.in_progress, label: "لە کاردایە", emoji: "🔄", activeColor: "bg-amber-500/25 border-amber-500/50 text-amber-300"   },
              { status: SubtitleStatus.unavailable, label: "نییە",       emoji: "❌", activeColor: "bg-red-500/25 border-red-500/50 text-red-300"           },
            ] as const).map(({ status, label, activeColor }) => {
              const isActive = movie.subtitleStatus === status;
              return (
                <button
                  key={status}
                  onClick={() => handleSubtitleStatus(status)}
                  disabled={isUpdatingMeta}
                  className={`flex-1 py-2.5 px-2 rounded-xl border text-xs font-bold transition-all ${
                    isActive ? activeColor : "bg-zinc-900/60 border-zinc-800 text-zinc-500 hover:border-zinc-700 hover:text-zinc-400"
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Where to Watch in Kurdish */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Globe size={14} className="text-zinc-500" />
              <h2 className="text-sm font-bold text-zinc-300">لە کوێ ببینیت بە کوردی</h2>
            </div>
            {availablePlatforms.length > 0 && (
              <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                {availablePlatforms.length} ماڵپەڕ
              </span>
            )}
          </div>

          {platformsToShow.length === 0 ? (
            <div className="text-center py-6 text-zinc-600 text-sm">
              <Globe size={28} className="mx-auto mb-2 opacity-40" />
              لە هیچ ماڵپەڕێکدا دۆزرایەوە نییە
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2">
              {platformsToShow.map((platform) => (
                <a
                  key={platform.id}
                  href={platform.url(movie.titleEn)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center justify-between px-4 py-3 rounded-xl border bg-gradient-to-l ${platform.color} to-transparent ${platform.border} group hover:opacity-90 transition-opacity`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-black/30 border border-white/5 flex items-center justify-center">
                      <Clapperboard size={14} className="text-zinc-400" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">{platform.label}</p>
                      <p className="text-[10px] text-zinc-500 font-normal" dir="ltr">{platform.site}</p>
                    </div>
                  </div>
                  <ExternalLink size={13} className="text-zinc-500 group-hover:text-zinc-300 transition-colors" />
                </a>
              ))}
            </div>
          )}

          <p className="text-[10px] text-zinc-600 mt-2 text-center" dir="rtl">
            {availablePlatforms.length > 0
              ? "ئەم ماڵپەڕانە ئەم فیلمەیان هەیە"
              : `گەڕانی تایبەت بۆ "${movie.titleEn}" لە هەر ماڵپەڕێکدا`
            }
          </p>
        </div>
      </div>
    </div>
  );
}
