import { useListWatchlist, useDeleteWatchEntry, getListWatchlistQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { StarRating } from "@/components/StarRating";
import { formatDate } from "@/lib/utils";
import { Link } from "wouter";

export default function Log() {
  const { data: watchlist = [], isLoading } = useListWatchlist();
  const { mutate: deleteEntry } = useDeleteWatchEntry();
  const queryClient = useQueryClient();

  const handleDelete = (id: number) => {
    deleteEntry({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListWatchlistQueryKey() });
      }
    });
  };

  return (
    <div className="min-h-screen pb-24" dir="rtl">
      <div className="sticky top-0 z-40 bg-black/90 backdrop-blur-xl border-b border-zinc-800/60">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-base font-bold text-white">ڕۆژنامەی فیلم</h1>
          <span className="text-xs text-zinc-500">{watchlist.length} تۆمار</span>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 pt-4">
        {isLoading ? (
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="h-20 bg-zinc-900 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : watchlist.length > 0 ? (
          <div className="space-y-3">
            {watchlist.map((entry) => (
              <div key={entry.id} className="bg-zinc-900/80 border border-zinc-800/60 rounded-xl overflow-hidden">
                <div className="flex items-stretch gap-3 p-3">
                  {entry.movie && (
                    <Link href={`/movie/${entry.movie.id}`}>
                      <img
                        src={entry.movie.imageUrl || "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=80&h=120&fit=crop"}
                        alt={entry.movie.titleKu}
                        className="w-14 h-20 object-cover rounded-lg flex-shrink-0 cursor-pointer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=80&h=120&fit=crop";
                        }}
                      />
                    </Link>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="text-white text-sm font-semibold line-clamp-1">
                          {entry.movie?.titleKu || "فیلمی نەناسراو"}
                        </p>
                        <p className="text-zinc-500 text-xs">
                          {entry.movie?.titleEn} · {entry.movie?.year}
                        </p>
                      </div>
                      <button
                        onClick={() => handleDelete(entry.id)}
                        className="text-zinc-600 hover:text-red-400 text-xs w-6 h-6 flex items-center justify-center flex-shrink-0 transition-colors"
                      >
                        ×
                      </button>
                    </div>

                    {entry.rating ? (
                      <div className="flex items-center gap-2 mt-1.5">
                        <StarRating value={entry.rating} readonly size="sm" />
                        <span className="text-amber-400 text-xs font-bold">{entry.rating}</span>
                      </div>
                    ) : (
                      <p className="text-zinc-600 text-xs mt-1.5">نمرە نەدراوە</p>
                    )}

                    {entry.review && (
                      <p className="text-zinc-400 text-xs mt-1.5 line-clamp-2 leading-relaxed">
                        "{entry.review}"
                      </p>
                    )}

                    <p className="text-zinc-700 text-[10px] mt-1.5">
                      {formatDate(entry.watchedAt)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-5xl mb-4">📔</p>
            <p className="text-zinc-400 font-medium">ڕۆژنامەکەت بەتاڵە</p>
            <p className="text-zinc-600 text-sm mt-2">فیلمێک ببینە و نمرەی بدەیت</p>
            <Link href="/discover">
              <button className="mt-5 px-5 py-2.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-xl text-sm hover:bg-amber-500/20 transition-colors">
                دۆزینەوەی فیلم
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
