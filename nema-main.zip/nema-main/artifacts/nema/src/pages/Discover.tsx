import { useState, useMemo } from "react";
import { useListMovies } from "@workspace/api-client-react";
import { MovieCard } from "@/components/MovieCard";
import { Link } from "wouter";

const GENRES = ["هەمووی", "Drama", "Action", "Sci-Fi", "Crime", "Thriller", "Fantasy", "Animation", "Romance", "Comedy", "Documentary", "Western"];
const GENRE_KU: Record<string, string> = {
  "هەمووی": "هەمووی",
  "Drama": "دراما",
  "Action": "ئەکشن",
  "Sci-Fi": "ساینس فیکشن",
  "Crime": "تاوانکاری",
  "Thriller": "تریلەر",
  "Fantasy": "فانتازی",
  "Animation": "ئەنیمەیشن",
  "Romance": "ئاشقانە",
  "Comedy": "کۆمیدی",
  "Documentary": "بەلگەنامە",
  "Western": "ڕۆژئاوا",
};

export default function Discover() {
  const [search, setSearch] = useState("");
  const [activeGenre, setActiveGenre] = useState("هەمووی");
  const [typeFilter, setTypeFilter] = useState<"all" | "movie" | "series">("all");

  const { data: allMovies = [], isLoading } = useListMovies({ q: search || undefined });

  const genreCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const m of allMovies) {
      counts[m.genre] = (counts[m.genre] || 0) + 1;
    }
    return counts;
  }, [allMovies]);

  const typeCounts = useMemo(() => ({
    all: allMovies.length,
    movie: allMovies.filter(m => m.type === "movie").length,
    series: allMovies.filter(m => m.type === "series").length,
  }), [allMovies]);

  const filtered = useMemo(() => {
    return allMovies.filter(m => {
      if (typeFilter === "movie" && m.type !== "movie") return false;
      if (typeFilter === "series" && m.type !== "series") return false;
      if (activeGenre !== "هەمووی" && m.genre !== activeGenre) return false;
      return true;
    });
  }, [allMovies, typeFilter, activeGenre]);

  const genreCountForFilter = (genre: string) => {
    if (genre === "هەمووی") {
      if (typeFilter === "all") return allMovies.length;
      return typeCounts[typeFilter];
    }
    return allMovies.filter(m => {
      if (typeFilter === "movie" && m.type !== "movie") return false;
      if (typeFilter === "series" && m.type !== "series") return false;
      return m.genre === genre;
    }).length;
  };

  return (
    <div className="min-h-screen pb-24" dir="rtl">
      <div className="sticky top-0 z-40 bg-black/90 backdrop-blur-xl border-b border-zinc-800/60">
        <div className="max-w-md mx-auto px-4 pt-3 pb-2">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-base font-bold text-white">دۆزینەوە</h1>
            <Link href="/add">
              <button className="text-xs text-amber-400 border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 rounded-lg hover:bg-amber-500/20 transition-colors">
                + زیادکردن
              </button>
            </Link>
          </div>

          {/* Search */}
          <div className="relative mb-3">
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">⌕</span>
            <input
              type="search"
              placeholder="گەڕان بە کوردی یان ئینگلیزی..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-zinc-900/80 border border-zinc-800 rounded-xl pr-9 pl-4 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-500/50 transition-colors"
              dir="rtl"
            />
          </div>

          {/* Type filter with counts */}
          <div className="flex gap-2 mb-2" dir="rtl">
            {([["all", "هەمووی"], ["movie", "فیلم"], ["series", "زنجیرە"]] as const).map(([val, label]) => (
              <button
                key={val}
                onClick={() => setTypeFilter(val)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-all flex items-center gap-1 ${
                  typeFilter === val
                    ? "bg-amber-500 text-black"
                    : "bg-zinc-900 text-zinc-400 border border-zinc-800 hover:border-zinc-700"
                }`}
              >
                {label}
                <span className={`text-[10px] font-bold px-1 py-0.5 rounded-full ${
                  typeFilter === val ? "bg-black/20 text-black" : "bg-zinc-800 text-zinc-500"
                }`}>
                  {typeCounts[val]}
                </span>
              </button>
            ))}
          </div>

          {/* Genre chips with counts */}
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide" style={{ scrollbarWidth: "none" }}>
            {GENRES.map((genre) => {
              const count = genreCountForFilter(genre);
              if (genre !== "هەمووی" && count === 0) return null;
              return (
                <button
                  key={genre}
                  onClick={() => setActiveGenre(genre)}
                  className={`flex-shrink-0 px-2.5 py-1 rounded-full text-xs font-medium transition-all flex items-center gap-1 ${
                    activeGenre === genre
                      ? "bg-amber-500 text-black"
                      : "bg-zinc-900 text-zinc-400 border border-zinc-800 hover:border-zinc-700"
                  }`}
                >
                  {GENRE_KU[genre] || genre}
                  <span className={`text-[10px] font-bold px-1 rounded-full ${
                    activeGenre === genre ? "bg-black/20 text-black" : "bg-zinc-800 text-zinc-500"
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 pt-4">
        {isLoading ? (
          <div className="grid grid-cols-3 gap-2">
            {Array(9).fill(0).map((_, i) => (
              <div key={i} className="aspect-[2/3] bg-zinc-900 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filtered.length > 0 ? (
          <>
            <p className="text-zinc-600 text-xs mb-3">
              {filtered.length} {filtered.filter(m => m.type === "series").length > 0 && filtered.filter(m => m.type === "movie").length > 0
                ? "فیلم و زنجیرە"
                : filtered[0]?.type === "series" ? "زنجیرە" : "فیلم"}
            </p>
            <div className="grid grid-cols-3 gap-2">
              {filtered.map((movie) => (
                <MovieCard key={movie.id} movie={movie} size="sm" />
              ))}
            </div>
          </>
        ) : (
          <div className="text-center py-16">
            <p className="text-4xl mb-3">🔍</p>
            <p className="text-zinc-400">هیچ فیلمێک نەدۆزرایەوە</p>
            <p className="text-zinc-600 text-sm mt-1">گەڕانەکەت بگۆڕە</p>
          </div>
        )}
      </div>
    </div>
  );
}
