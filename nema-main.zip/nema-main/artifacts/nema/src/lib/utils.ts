import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string | Date) {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function getRatingColor(rating: number) {
  if (rating >= 4) return "text-amber-400";
  if (rating >= 3) return "text-yellow-500";
  if (rating >= 2) return "text-orange-500";
  return "text-red-500";
}
