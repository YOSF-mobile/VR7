import { useState } from "react";
import { cn } from "@/lib/utils";
import { Star } from "lucide-react";

interface StarRatingProps {
  value: number;
  onChange?: (val: number) => void;
  readonly?: boolean;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
}

const RATING_LABELS: Record<number, string> = {
  1: "خراپ",
  2: "ناوەند",
  3: "باش",
  4: "زۆر باش",
  5: "نایاب",
};

export function StarRating({
  value,
  onChange,
  readonly = false,
  size = "md",
  showLabel = false,
}: StarRatingProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const [popped, setPopped] = useState<number | null>(null);

  const sizeMap = {
    sm: { px: 14, gap: "gap-0.5" },
    md: { px: 22, gap: "gap-1" },
    lg: { px: 30, gap: "gap-1.5" },
  }[size];

  const display = hovered ?? value;

  const handleClick = (star: number) => {
    if (readonly) return;
    onChange?.(star);
    setPopped(star);
    setTimeout(() => setPopped(null), 300);
  };

  return (
    <div className="flex flex-col items-start gap-1">
      <div className={cn("flex flex-row-reverse", sizeMap.gap)} dir="ltr">
        {[5, 4, 3, 2, 1].map((star) => {
          const filled = display >= star;
          const isPopped = popped === star;

          return (
            <button
              key={star}
              type="button"
              disabled={readonly}
              className={cn(
                "transition-all duration-150 focus:outline-none",
                !readonly && "cursor-pointer hover:scale-125 active:scale-95",
                readonly && "cursor-default",
                isPopped && "star-pop"
              )}
              onMouseEnter={() => !readonly && setHovered(star)}
              onMouseLeave={() => !readonly && setHovered(null)}
              onClick={() => handleClick(star)}
              aria-label={`نمرەی ${star}`}
            >
              <Star
                size={sizeMap.px}
                strokeWidth={1.5}
                className={cn(
                  "transition-all duration-150",
                  filled
                    ? "fill-amber-400 stroke-amber-400 drop-shadow-[0_0_4px_rgba(251,191,36,0.5)]"
                    : "fill-transparent stroke-zinc-600",
                  !readonly && !filled && "hover:stroke-amber-400/50"
                )}
              />
            </button>
          );
        })}
      </div>
      {showLabel && !readonly && display > 0 && (
        <span className="text-[11px] text-amber-400 font-medium">
          {RATING_LABELS[Math.round(display)] ?? ""}
        </span>
      )}
    </div>
  );
}
