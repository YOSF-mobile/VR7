import { useState } from "react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Star, Clapperboard, Captions } from "lucide-react";

interface Movie {
  id: number;
  titleEn: string;
  titleKu: string;
  year: number;
  genre: string;
  type: string;
  imageUrl?: string | null;
  isKurdish: boolean;
  subtitleStatus?: string | null;
}

interface MovieCardProps {
  movie: Movie;
  rating?: number | null;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const GENRE_MAP: Record<string, string> = {
  "Drama": "دراما",
  "Action": "ئەکشن",
  "Sci-Fi": "ساینس فیکشن",
  "Crime": "تاوانکاری",
  "Thriller": "تریلەر",
  "Fantasy": "فانتازی",
  "Animation": "ئەنیمەیشن",
  "Romance": "ئاشقانە",
  "Comedy": "کۆمیدی",
  "Documentary": "بەلگەنامە",
  "Western": "ڕۆژئاوا",
};

const GENRE_GRADIENT: Record<string, string> = {
  "Drama":       "from-slate-900 via-slate-800 to-slate-700",
  "Action":      "from-red-950 via-red-900 to-orange-800",
  "Sci-Fi":      "from-blue-950 via-blue-900 to-cyan-800",
  "Crime":       "from-zinc-900 via-zinc-800 to-stone-700",
  "Thriller":    "from-gray-950 via-gray-900 to-neutral-700",
  "Fantasy":     "from-purple-950 via-purple-900 to-violet-800",
  "Animation":   "from-emerald-950 via-emerald-900 to-teal-700",
  "Romance":     "from-rose-950 via-rose-900 to-pink-800",
  "Comedy":      "from-amber-950 via-amber-900 to-yellow-800",
  "Documentary": "from-stone-900 via-stone-800 to-stone-700",
  "Western":     "from-orange-950 via-amber-900 to-yellow-800",
};

export function MovieCard({ movie, rating, size = "md", className }: MovieCardProps) {
  const [imgError, setImgError] = useState(false);
  const imgUrl = movie.imageUrl || null;
  const gradient = GENRE_GRADIENT[movie.genre] || "from-zinc-900 via-zinc-800 to-zinc-700";

  return (
    <Link href={`/movie/${movie.id}`}>
      <div
        className={cn(
          "group relative overflow-hidden rounded-xl cursor-pointer aspect-[2/3]",
          "bg-zinc-900",
          "transition-transform duration-300 hover:scale-[1.02] hover:shadow-2xl",
          className
        )}
      >
        {imgUrl && !imgError ? (
          <img
            src={imgUrl}
            alt={movie.titleKu}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className={cn("w-full h-full bg-gradient-to-b", gradient, "flex flex-col items-center justify-center p-3")}>
            <Clapperboard size={size === "sm" ? 22 : 32} className="text-white/20 mb-2" />
            <p className="text-white/40 text-center font-medium leading-tight"
               style={{ fontSize: size === "sm" ? "9px" : "11px" }}>
              {movie.titleKu}
            </p>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />

        {movie.isKurdish && (
          <div className="absolute top-2 right-2 bg-amber-500/90 text-black text-[10px] font-bold px-2 py-0.5 rounded-full">
            کوردی
          </div>
        )}

        {rating && (
          <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-sm text-amber-400 text-xs font-bold px-2 py-1 rounded-lg flex items-center gap-1">
            <Star size={10} className="fill-amber-400 stroke-amber-400" />
            <span>{rating}</span>
          </div>
        )}

        <div className="absolute bottom-0 right-0 left-0 p-3">
          <p className="text-white font-semibold text-sm leading-tight line-clamp-2">
            {movie.titleKu}
          </p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-zinc-400 text-xs">{movie.year}</span>
            <span className="text-zinc-600 text-xs">·</span>
            <span className="text-zinc-400 text-xs">
              {GENRE_MAP[movie.genre] || movie.genre}
            </span>
            {movie.type === "series" && (
              <>
                <span className="text-zinc-600 text-xs">·</span>
                <span className="text-amber-500/70 text-xs">زنجیرە</span>
              </>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
