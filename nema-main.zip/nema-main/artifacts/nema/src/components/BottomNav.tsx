import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Home, Compass, Trophy, BookOpen, User } from "lucide-react";

const NAV_ITEMS = [
  { href: "/", label: "سەرەکی", Icon: Home },
  { href: "/discover", label: "دۆزینەوە", Icon: Compass },
  { href: "/top-rated", label: "بەرزترین", Icon: Trophy },
  { href: "/log", label: "ڕۆژنامە", Icon: BookOpen },
  { href: "/profile", label: "پرۆفایل", Icon: User },
];

export function BottomNav() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 flex justify-center">
      <div className="w-full max-w-md bg-black/95 backdrop-blur-xl border-t border-zinc-800/80">
        <div className="flex items-center justify-around px-1 py-2">
          {NAV_ITEMS.map((item) => {
            const active =
              location === item.href ||
              (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <button
                  className={cn(
                    "relative flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all duration-200",
                    active
                      ? "text-amber-400"
                      : "text-zinc-500 hover:text-zinc-300"
                  )}
                >
                  <item.Icon
                    size={20}
                    strokeWidth={active ? 2.5 : 1.8}
                    className={cn(
                      "transition-all duration-200",
                      active && "drop-shadow-[0_0_6px_rgba(251,191,36,0.6)]"
                    )}
                  />
                  <span className="text-[9px] font-medium leading-none">{item.label}</span>
                  {active && (
                    <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-5 h-0.5 bg-amber-400 rounded-full" />
                  )}
                </button>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
