import { Router } from "express";
import { db, favoritesTable, moviesTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";
import { AddFavoriteBody, DeleteFavoriteParams } from "@workspace/api-zod";

const router = Router();

router.get("/", async (_req, res) => {
  const favorites = await db
    .select({
      id: favoritesTable.id,
      movieId: favoritesTable.movieId,
      position: favoritesTable.position,
      movie: moviesTable,
    })
    .from(favoritesTable)
    .leftJoin(moviesTable, eq(favoritesTable.movieId, moviesTable.id))
    .orderBy(favoritesTable.position);
  res.json(favorites);
});

router.post("/", async (req, res) => {
  const parsed = AddFavoriteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [existingCount] = await db.select({ count: count() }).from(favoritesTable);
  if (existingCount.count >= 4) {
    res.status(400).json({ error: "Maximum 4 favorites allowed" });
    return;
  }
  const existing = await db.select().from(favoritesTable).where(eq(favoritesTable.movieId, parsed.data.movieId));
  if (existing.length > 0) {
    res.status(400).json({ error: "Movie is already in favorites" });
    return;
  }
  const [favorite] = await db.insert(favoritesTable).values(parsed.data).returning();
  const [movie] = await db.select().from(moviesTable).where(eq(moviesTable.id, favorite.movieId));
  res.status(201).json({ ...favorite, movie });
});

router.delete("/:id", async (req, res) => {
  const parsed = DeleteFavoriteParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }
  await db.delete(favoritesTable).where(eq(favoritesTable.id, parsed.data.id));
  res.status(204).send();
});

export default router;
