import { Router } from "express";
import { db, moviesTable } from "@workspace/db";
import { openai } from "@workspace/integrations-openai-ai-server";
import { isNull, or, eq, and, gt } from "drizzle-orm";

const router = Router();

interface JobStatus {
  running: boolean;
  total: number;
  processed: number;
  success: number;
  failed: number;
  startedAt: Date | null;
  finishedAt: Date | null;
  lastTitle: string;
}

const summaryJob: JobStatus = {
  running: false, total: 0, processed: 0, success: 0, failed: 0,
  startedAt: null, finishedAt: null, lastTitle: ""
};
const detailsJob: JobStatus = {
  running: false, total: 0, processed: 0, success: 0, failed: 0,
  startedAt: null, finishedAt: null, lastTitle: ""
};

async function generateKurdishSummary(
  titleEn: string,
  description: string,
  genre: string,
  year: number,
  type: string
): Promise<string> {
  const typeKu = type === "series" ? "زنجیرە" : "فیلم";
  const prompt = `You are a Kurdish (Sorani) cinema expert. Write a brief, engaging movie/series summary in NATURAL CONVERSATIONAL SORANI KURDISH.

Rules:
- Exactly 2 sentences only
- Warm, engaging tone like recommending to a Kurdish friend  
- Use Sorani Kurdish script only (کوردی سۆرانی), NOT Kurmanji
- Do NOT translate the title — keep the English title as-is
- First sentence: what the story is about
- Second sentence: hint at why it's worth watching

Movie: "${titleEn}" (${year}) — ${typeKu} — Genre: ${genre}
English description: ${description}

Write ONLY the 2 Sorani Kurdish sentences:`;

  const response = await openai.chat.completions.create({
    model: "gpt-5-mini",
    messages: [{ role: "user", content: prompt }],
  });

  return response.choices[0]?.message?.content?.trim() ?? "";
}

async function enrichMovieDetails(
  titleEn: string,
  description: string,
  genre: string,
  year: number,
  type: string
): Promise<{ director: string; cast: string; runtime: number | null }> {
  const prompt = `Based on your knowledge of this movie/series, provide accurate details in JSON format.

Movie: "${titleEn}" (${year}) — ${genre} — ${type}
Description: ${description}

Return ONLY valid JSON (no markdown, no explanation) with these fields:
{
  "director": "Full Name" (or "Unknown" if not sure),
  "cast": "Actor1, Actor2, Actor3" (top 3-4 main actors only),
  "runtime": 120 (in minutes for movies, average episode length for series, or null if unknown)
}`;

  const response = await openai.chat.completions.create({
    model: "gpt-5-mini",
    messages: [{ role: "user", content: prompt }],
  });

  const content = response.choices[0]?.message?.content?.trim() ?? "{}";
  const cleaned = content.replace(/```json|```/g, "").trim();
  return JSON.parse(cleaned);
}

async function runSummaryJob() {
  if (summaryJob.running) return;

  try {
    const movies = await db
      .select()
      .from(moviesTable)
      .where(or(isNull(moviesTable.kurdishSummaryAi), eq(moviesTable.kurdishSummaryAi, "")));

    summaryJob.running = true;
    summaryJob.total = movies.length;
    summaryJob.processed = 0;
    summaryJob.success = 0;
    summaryJob.failed = 0;
    summaryJob.startedAt = new Date();
    summaryJob.finishedAt = null;

    console.log(`[Admin] Starting Kurdish summary generation for ${movies.length} movies`);

    for (const movie of movies) {
      const desc = movie.description || `A ${movie.genre} ${movie.type} from ${movie.year}.`;
      summaryJob.lastTitle = movie.titleEn;

      try {
        const summary = await generateKurdishSummary(
          movie.titleEn, desc, movie.genre, movie.year, movie.type
        );

        if (summary) {
          await db.update(moviesTable)
            .set({ kurdishSummaryAi: summary })
            .where(eq(moviesTable.id, movie.id));
          summaryJob.success++;
        } else {
          summaryJob.failed++;
        }
      } catch (err: any) {
        summaryJob.failed++;
        console.error(`[Admin] Summary failed for ${movie.titleEn}:`, err.message);
      }

      summaryJob.processed++;
      await new Promise(r => setTimeout(r, 200));
    }

    summaryJob.finishedAt = new Date();
    summaryJob.running = false;
    console.log(`[Admin] Summary generation done. Success: ${summaryJob.success}, Failed: ${summaryJob.failed}`);
  } catch (err: any) {
    summaryJob.running = false;
    console.error("[Admin] Summary job error:", err.message);
  }
}

async function runDetailsJob() {
  if (detailsJob.running) return;

  try {
    const movies = await db
      .select()
      .from(moviesTable)
      .where(or(isNull(moviesTable.director), eq(moviesTable.director, "")));

    detailsJob.running = true;
    detailsJob.total = movies.length;
    detailsJob.processed = 0;
    detailsJob.success = 0;
    detailsJob.failed = 0;
    detailsJob.startedAt = new Date();
    detailsJob.finishedAt = null;

    console.log(`[Admin] Starting details enrichment for ${movies.length} movies`);

    for (const movie of movies) {
      const desc = movie.description || `A ${movie.genre} ${movie.type} from ${movie.year}.`;
      detailsJob.lastTitle = movie.titleEn;

      try {
        const details = await enrichMovieDetails(
          movie.titleEn, desc, movie.genre, movie.year, movie.type
        );

        const updateData: Record<string, unknown> = {};
        if (details.director && details.director !== "Unknown") updateData.director = details.director;
        if (details.cast) updateData.cast = details.cast;
        if (details.runtime) updateData.runtime = details.runtime;

        if (Object.keys(updateData).length > 0) {
          await db.update(moviesTable)
            .set(updateData)
            .where(eq(moviesTable.id, movie.id));
          detailsJob.success++;
        }
      } catch (err: any) {
        detailsJob.failed++;
        console.error(`[Admin] Details failed for ${movie.titleEn}:`, err.message);
      }

      detailsJob.processed++;
      await new Promise(r => setTimeout(r, 200));
    }

    detailsJob.finishedAt = new Date();
    detailsJob.running = false;
    console.log(`[Admin] Details enrichment done. Success: ${detailsJob.success}, Failed: ${detailsJob.failed}`);
  } catch (err: any) {
    detailsJob.running = false;
    console.error("[Admin] Details job error:", err.message);
  }
}

router.post("/generate-summaries", (req, res) => {
  if (summaryJob.running) {
    return res.json({ status: "already_running", ...summaryJob });
  }
  setImmediate(() => runSummaryJob());
  res.json({ status: "started", message: "Kurdish summary generation started in background" });
});

router.post("/enrich-details", (req, res) => {
  if (detailsJob.running) {
    return res.json({ status: "already_running", ...detailsJob });
  }
  setImmediate(() => runDetailsJob());
  res.json({ status: "started", message: "Movie details enrichment started in background" });
});

router.get("/status", (req, res) => {
  res.json({
    summaries: summaryJob,
    details: detailsJob,
  });
});

export default router;
