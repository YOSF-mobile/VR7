import { Router } from "express";
import { db, moviesTable, watchlistTable, favoritesTable } from "@workspace/db";
import { eq, ilike, or, and, avg, count, desc } from "drizzle-orm";
import { CreateMovieBody, ListMoviesQueryParams, GetMovieParams, UpdateMovieBody, UpdateMovieParams, DeleteMovieParams } from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const parsed = ListMoviesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { q, genre, year } = parsed.data;

  let query = db.select().from(moviesTable).$dynamic();

  const conditions = [];
  if (q) {
    conditions.push(
      or(
        ilike(moviesTable.titleEn, `%${q}%`),
        ilike(moviesTable.titleKu, `%${q}%`)
      )!
    );
  }
  if (genre) {
    conditions.push(eq(moviesTable.genre, genre));
  }
  if (year) {
    conditions.push(eq(moviesTable.year, Number(year)));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  const movies = await query.orderBy(desc(moviesTable.createdAt));
  res.json(movies);
});

router.post("/", async (req, res) => {
  const parsed = CreateMovieBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [movie] = await db.insert(moviesTable).values(parsed.data).returning();
  res.status(201).json(movie);
});

router.get("/stats", async (req, res) => {
  const [totalMoviesResult] = await db.select({ count: count() }).from(moviesTable);
  const [totalWatchedResult] = await db.select({ count: count() }).from(watchlistTable);
  const [totalKurdishResult] = await db.select({ count: count() }).from(moviesTable).where(eq(moviesTable.isKurdish, true));
  const [avgRatingResult] = await db.select({ avg: avg(watchlistTable.rating) }).from(watchlistTable);

  const genreRows = await db
    .select({ genre: moviesTable.genre, count: count() })
    .from(moviesTable)
    .groupBy(moviesTable.genre)
    .orderBy(desc(count()));

  res.json({
    totalMovies: totalMoviesResult.count,
    totalWatched: totalWatchedResult.count,
    totalKurdish: totalKurdishResult.count,
    avgRating: avgRatingResult.avg ? Number(Number(avgRatingResult.avg).toFixed(1)) : 0,
    genreBreakdown: genreRows.map(r => ({ genre: r.genre, count: r.count })),
  });
});

router.get("/:id", async (req, res) => {
  const parsed = GetMovieParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }
  const [movie] = await db.select().from(moviesTable).where(eq(moviesTable.id, parsed.data.id));
  if (!movie) {
    res.status(404).json({ error: "Movie not found" });
    return;
  }
  const [watchEntry] = await db.select().from(watchlistTable).where(eq(watchlistTable.movieId, movie.id)).orderBy(desc(watchlistTable.watchedAt)).limit(1);
  const [favorite] = await db.select().from(favoritesTable).where(eq(favoritesTable.movieId, movie.id));
  res.json({ ...movie, watchEntry: watchEntry ?? null, isFavorite: !!favorite });
});

router.put("/:id", async (req, res) => {
  const parsedParams = UpdateMovieParams.safeParse({ id: Number(req.params.id) });
  const parsedBody = UpdateMovieBody.safeParse(req.body);
  if (!parsedParams.success || !parsedBody.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [movie] = await db
    .update(moviesTable)
    .set(parsedBody.data)
    .where(eq(moviesTable.id, parsedParams.data.id))
    .returning();
  if (!movie) {
    res.status(404).json({ error: "Movie not found" });
    return;
  }
  res.json(movie);
});

router.delete("/:id", async (req, res) => {
  const parsed = DeleteMovieParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }
  await db.delete(moviesTable).where(eq(moviesTable.id, parsed.data.id));
  res.status(204).send();
});

export default router;
