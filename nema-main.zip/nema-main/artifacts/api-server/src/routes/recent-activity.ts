import { Router } from "express";
import { db, watchlistTable, moviesTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/", async (_req, res) => {
  const entries = await db
    .select({
      id: watchlistTable.id,
      movieId: watchlistTable.movieId,
      rating: watchlistTable.rating,
      review: watchlistTable.review,
      watchedAt: watchlistTable.watchedAt,
      movie: moviesTable,
    })
    .from(watchlistTable)
    .leftJoin(moviesTable, eq(watchlistTable.movieId, moviesTable.id))
    .orderBy(desc(watchlistTable.watchedAt))
    .limit(10);
  res.json(entries);
});

export default router;
