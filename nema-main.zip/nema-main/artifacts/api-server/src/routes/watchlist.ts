import { Router } from "express";
import { db, watchlistTable, moviesTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { CreateWatchEntryBody, UpdateWatchEntryParams, UpdateWatchEntryBody, DeleteWatchEntryParams } from "@workspace/api-zod";

const router = Router();

router.get("/", async (_req, res) => {
  const entries = await db
    .select({
      id: watchlistTable.id,
      movieId: watchlistTable.movieId,
      rating: watchlistTable.rating,
      review: watchlistTable.review,
      watchedAt: watchlistTable.watchedAt,
      movie: moviesTable,
    })
    .from(watchlistTable)
    .leftJoin(moviesTable, eq(watchlistTable.movieId, moviesTable.id))
    .orderBy(desc(watchlistTable.watchedAt));
  res.json(entries);
});

router.post("/", async (req, res) => {
  const parsed = CreateWatchEntryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [entry] = await db.insert(watchlistTable).values(parsed.data).returning();
  const [movie] = await db.select().from(moviesTable).where(eq(moviesTable.id, entry.movieId));
  res.status(201).json({ ...entry, movie });
});

router.put("/:id", async (req, res) => {
  const parsedParams = UpdateWatchEntryParams.safeParse({ id: Number(req.params.id) });
  const parsedBody = UpdateWatchEntryBody.safeParse(req.body);
  if (!parsedParams.success || !parsedBody.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [entry] = await db
    .update(watchlistTable)
    .set(parsedBody.data)
    .where(eq(watchlistTable.id, parsedParams.data.id))
    .returning();
  if (!entry) {
    res.status(404).json({ error: "Entry not found" });
    return;
  }
  const [movie] = await db.select().from(moviesTable).where(eq(moviesTable.id, entry.movieId));
  res.json({ ...entry, movie });
});

router.delete("/:id", async (req, res) => {
  const parsed = DeleteWatchEntryParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid ID" });
    return;
  }
  await db.delete(watchlistTable).where(eq(watchlistTable.id, parsed.data.id));
  res.status(204).send();
});

export default router;
