import { Router, type IRouter } from "express";
import healthRouter from "./health";
import moviesRouter from "./movies";
import watchlistRouter from "./watchlist";
import favoritesRouter from "./favorites";
import recentActivityRouter from "./recent-activity";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/movies", moviesRouter);
router.use("/watchlist", watchlistRouter);
router.use("/favorites", favoritesRouter);
router.use("/recent-activity", recentActivityRouter);
router.use("/admin", adminRouter);

export default router;
