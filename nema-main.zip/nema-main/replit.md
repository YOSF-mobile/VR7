# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Artifacts

### Nema (`artifacts/nema`) — previewPath: `/`
Kurdish RTL movie/series social tracking app (like Letterboxd).

**Features:**
- Full RTL Kurdish Sorani interface using Vazirmatn font
- Dark cinematic theme with amber/gold accents and film grain overlay
- Browse & search 27+ pre-seeded movies (global + Kurdish films)
- Log watched movies, give star ratings (0.5–5), write Kurdish reviews
- "Top 4" Favorites grid on profile page
- Manual "Add Movie" form for adding any film or series
- Dashboard with stats (total watched, avg rating, Kurdish film count)
- Genre & type filtering on discover page
- Recent activity feed on homepage

**Pages:**
- `/` — Home dashboard with stats, featured movie, recent activity
- `/discover` — Movie browser with search, genre filters, type filters
- `/profile` — User profile with Top 4 favorites grid and stats
- `/log` — Watch diary with all logged movies and reviews
- `/add` — Form to manually add a new movie/series
- `/movie/:id` — Movie detail with watch/rate/review form and favorite toggle

### API Server (`artifacts/api-server`) — previewPath: `/api`
Express 5 REST API serving all data.

**Routes:**
- `GET/POST /api/movies` — List (with search/filter) and create movies
- `GET/PUT/DELETE /api/movies/:id` — CRUD for individual movies
- `GET /api/movies/stats` — Dashboard stats (totals, avg rating, genre breakdown)
- `GET/POST /api/watchlist` — List and create watch entries
- `PUT/DELETE /api/watchlist/:id` — Update/delete watch entries
- `GET/POST /api/favorites` — List and add favorites (max 4)
- `DELETE /api/favorites/:id` — Remove from favorites
- `GET /api/recent-activity` — Last 10 watched movies

## Database Schema

**`movies`** — id, title_en, title_ku, year, genre, type, image_url, description, is_kurdish, created_at

**`watchlist`** — id, movie_id, rating, review, watched_at

**`favorites`** — id, movie_id, position

Pre-seeded with 27 movies: global classics + famous Kurdish films including Bekas, Half Moon, Turtles Can Fly, My Sweet Pepper Land, Memories on Stone, and more.

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
